<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/icons/favicon.ico')); ?>" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" />

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/util.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>" />

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fontawesome/css/all.css')); ?>" />



</head>

<body style="">
    <div class="limiter">
        <div class="container-login100">
            <div class="col-md-6 col-lg-7 col-xl-8 login100-more"
                style="background-image: url('<?php echo e(asset('images/Rectangle 5.png')); ?>');">
                <div class="img-fluid col-md-9 pt-5">
                    <img src="<?php echo e(asset('images/logo_white.png')); ?>" class="w-25" />
                </div>
                <div class="modal-title col-md-9">
                    <h1 class="text-white">
                        Simple Software to Track Attendance By Facest
                    </h1>
                </div>
                <div class="card-subtitle col-md-9">
                    <h6 class="text-white pt-3">
                        * No Special Device is Required - The Biometric Device is a
                        Mobile/Tablet
                    </h6>
                </div>
                <div class="img-fluid col-md-9 col-sm-6 mx-auto">
                    <img src="<?php echo e(asset('images/Group%2032.png')); ?>" class="w-100 h-50 m-t-100" />
                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-5 col-xl-4 wrap-login100">
                <div class="title">
                    <span class="login100-form-title p-l-70 p-r-50 p-b-89">
                        Login
                    </span>
                </div>
                <div class="circle-1 p-t-90 row"></div>
                <div class="circle-2 p-t-40 row"></div>

                <form id="form" data-parsley-validate="" class="col-12 d-flex flex-column align-items-center"
                    action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-11">
                        <?php if(Session::has('ok')): ?>
                        <small class="form-text text-success"><?php echo e(Session::get('ok')); ?></small>
                        <?php endif; ?>


                        <?php if(Session::has('lockLogin')): ?>
                        <small id="lockWrapper" class="form-text text-danger mb-2">You are locked. Please retry for
                            <span
                                id="countdown"><?php echo e(\Carbon\Carbon::now()->diffInSeconds(Session::get('lockLogin')->copy()->addMinutes(5), false)); ?></span>
                            seconds!</small>
                        <?php else: ?>
                        <?php $__errorArgs = ['mes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="form-text text-danger mb-2"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>

                        <div class="box">
                            <div class="wrap-input100">
                                <span class="icon"><i class="fal fa-envelope"></i></span>
                                <input class="input100" type="email" name="email" placeholder="Email"
                                    value="<?php echo e(old('email')); ?>" required data-parsley-type="email"
                                    data-parsley-trigger="change" data-parsley-errors-container="#errorBlock1" />
                                <span class="focus-input100 icon"></span>
                            </div>
                            <small id="errorBlock1" class="form-text text-danger"></small>

                            <div class="wrap-input100 validate-input mt-4" data-validate="Password is required">
                                <span class="icon"><i class="fal fa-key"></i></span>
                                <input class="input100" type="password" name="pass" placeholder="Password" required
                                    data-parsley-errors-container="#errorBlock2" data-parsley-minlength="8" />
                                <span class="focus-input100 icon"></span>
                            </div>
                            <small id="errorBlock2" class="form-text text-danger"></small>
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <div class="">
                                <input class="input-checkbox100-circle" id="ckb1" type="radio" name="remember-me" />
                                <label class="label-checkbox100-circle" for="ckb1">
                                    <span class="txt1">
                                        Remember me
                                    </span>
                                </label>
                            </div>

                            <a href="<?php echo e(route('forgotpass')); ?>" class="txt2 hov1">
                                Forgot password?
                            </a>
                        </div>
                        
                        <?php if(Session::has('reCaptcha')): ?>
                        <div class="mt-4 d-flex">
                            <div class="ml-auto">
                                <div class="g-recaptcha" data-sitekey="<?php echo e(config('app.sitekey','')); ?>"></div>
                            </div>
                        </div>
                        <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="d-flex">
                            <div class="ml-auto">
                                <small class="form-text text-danger"><?php echo e($message); ?></small>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="d-flex">
                            <div class="ml-auto">
                                <small id="errCaptcha" class="form-text text-danger"></small>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="d-flex mt-4">
                            <div class="ml-auto">
                                <button type="submit" class="btn btn-primary">LOGIN</button>
                            </div>
                        </div>
                    </div>

                </form>

                <div class="flex-m w-full p-b-33 row">
                    <div class="contact100-form-checkbox-login">
                        <label class="label-checkbox100-a" for="ckb1">
                            <span class="txt1">
                                Don't have an account?
                                <a href="<?php echo e(route('register')); ?>" class="txt2 hov1">
                                    Sign up
                                </a>
                            </span>
                        </label>
                    </div>
                </div>
                <div class="circle-3 row"></div>
                <div class="circle-4 row"></div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>

    <script src="https://www.google.com/recaptcha/api.js"></script>
    <script src="<?php echo e(asset('scripts/parsley.min.js')); ?>"></script>
    <script src="js/main.js"></script>

    <script type="text/javascript">
        // validate recaptcha
        $("#form").submit(function(event) {
        var recaptcha = $("#g-recaptcha-response").val();
        if (recaptcha === "") {
            event.preventDefault();
            $("#errCaptcha").text("Please check the recaptcha");
        }
        });

        // validate input
        $(function () {
          $('#form').parsley().on('field:validated', function() {
            var ok = $('.parsley-error').length === 0;
            $('.bs-callout-info').toggleClass('hidden', !ok);
            $('.bs-callout-warning').toggleClass('hidden', ok);
          })
          .on('form:submit', function() {
            return true; // Don't submit form for this demo
          });
        });

    </script>

    <?php if(Session::has('lockLogin')): ?>
    <script type="text/javascript">
        // countdown seconds
    var timeleft = parseInt($('#countdown').text());

    if(timeleft<=0){
        $(":input[name='email']").prop('disabled', false)
        $(":input[name='pass']").prop('disabled', false)
        $("button[type='submit']").prop('disabled', false);
        $('#lockWrapper').hide();
    }else{
        $(":input[name='email']").prop('disabled', true)
        $(":input[name='pass']").prop('disabled', true)
        $("button[type='submit']").prop('disabled', true);
        var countdownTimer = setInterval(function(){
        $('#countdown').text(timeleft--);
        if(timeleft <= 0){
            clearInterval(countdownTimer);
            $(":input[name='email']").prop('disabled', false)
            $(":input[name='pass']").prop('disabled', false)
            $("button[type='submit']").prop('disabled', false);
            $('#lockWrapper').hide();
            }
        },1000);
        }

    </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH D:\00_HK2_3\CNPM\Attendance_laravel\resources\views/login.blade.php ENDPATH**/ ?>