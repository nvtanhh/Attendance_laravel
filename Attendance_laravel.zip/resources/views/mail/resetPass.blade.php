<h2 style="
    background-color: #619c02;
    color: #f1f1f1;
    padding: 10px;
    text-align:  center;
    font-family: arial;
    border-radius: 8px 8px 0 0;
    margin-top: 20px;
    margin-bottom: 0px;
">THÔNG TIN TÀI KHOẢN</h2>


<div style="
    border: solid 1px #b7b7b7;
    margin-top:  0px;
    border-radius: 0 0 8px 8px;
    background-color: #f1f1f1;
    padding:  10px;
">

    <p>Xin Chào <strong> {{$name}}</strong></p>
    <br/>
    <p>
        Tài khoản của bạn được thiết lập lại mật khẩu.
        <br/>Password: {{$pass}}
    </p>
    <p>Thân mến</p>
</div>
